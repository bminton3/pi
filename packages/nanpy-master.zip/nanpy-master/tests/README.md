Testing
============

 - Install tox (http://tox.readthedocs.org)
 - connect Arduino with Nanpy firmware
 - edit config.py
 - run tox in project directory:
    
    tox
